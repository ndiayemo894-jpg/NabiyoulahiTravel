# État du projet

Version 1.0 — base fonctionnelle :
- [x] Identité Nabiyoulahi Travel
- [x] Tableau de bord
- [x] Base locale SQLite
- [x] Clients
- [x] Billets / visas / Omra / Hajj / hôtels / packs
- [x] Suivi total / payé / reste
- [x] Génération de facture PDF
- [x] Partage Android (WhatsApp si disponible)

Prochaine étape :
- comptes employés
- sauvegarde cloud
- notifications
- espace client
- recherche avancée
- QR de vérification
- modèles de factures multiples
- paiements en ligne
- synchronisation multi-téléphones
