package com.nabiyoulahi.travel;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "nabiyoulahi.db";
    private static final int DB_VERSION = 1;

    public DatabaseHelper(Context c) { super(c, DB_NAME, null, DB_VERSION); }

    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE clients(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, email TEXT)");
        db.execSQL("CREATE TABLE services(id INTEGER PRIMARY KEY AUTOINCREMENT, client TEXT, type TEXT, destination TEXT, amount REAL, paid REAL, date TEXT)");
    }

    @Override public void onUpgrade(SQLiteDatabase db, int oldV, int newV) { }

    public long addClient(String name, String phone, String email) {
        ContentValues v = new ContentValues();
        v.put("name", name); v.put("phone", phone); v.put("email", email);
        return getWritableDatabase().insert("clients", null, v);
    }

    public long addService(String client, String type, String destination, double amount, double paid, String date) {
        ContentValues v = new ContentValues();
        v.put("client", client); v.put("type", type); v.put("destination", destination);
        v.put("amount", amount); v.put("paid", paid); v.put("date", date);
        return getWritableDatabase().insert("services", null, v);
    }

    public int count(String table) {
        Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM " + table, null);
        int n = c.moveToFirst() ? c.getInt(0) : 0; c.close(); return n;
    }

    public double sum(String column) {
        Cursor c = getReadableDatabase().rawQuery("SELECT COALESCE(SUM(" + column + "),0) FROM services", null);
        double n = c.moveToFirst() ? c.getDouble(0) : 0; c.close(); return n;
    }
}
