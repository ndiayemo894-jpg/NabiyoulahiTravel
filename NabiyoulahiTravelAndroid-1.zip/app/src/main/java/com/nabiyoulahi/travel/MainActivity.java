package com.nabiyoulahi.travel;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    static final int NAVY = Color.rgb(16,43,85), GOLD = Color.rgb(201,149,36), CREAM = Color.rgb(248,246,240);
    LinearLayout root, content, nav;
    DatabaseHelper db;

    int dp(float x) { return (int)(x*getResources().getDisplayMetrics().density + .5f); }
    TextView tv(String s, float size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(8),dp(6),dp(8),dp(6)); return t;
    }
    Button btn(String label) {
        Button b = new Button(this); b.setText(label); b.setTextColor(Color.WHITE);
        b.setTextSize(13); b.setAllCaps(false); b.setBackground(round(NAVY,12)); return b;
    }
    GradientDrawable round(int color, int radius) {
        GradientDrawable g = new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(radius)); return g;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b); db = new DatabaseHelper(this); showDashboard();
    }

    void base(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(CREAM);
        LinearLayout head = new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(14),dp(10),dp(14),dp(10)); head.setBackgroundColor(NAVY);
        TextView h = tv(title,20,Color.WHITE); h.setTypeface(null,1);
        head.addView(h,new LinearLayout.LayoutParams(0,dp(52),1));
        root.addView(head);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(14),dp(14),dp(14),dp(10));
        ScrollView scroll = new ScrollView(this); scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav = new LinearLayout(this); nav.setPadding(dp(6),dp(6),dp(6),dp(6)); nav.setBackgroundColor(Color.WHITE);
        String[] labels={"Accueil","Clients","Services","Facture"};
        for(String x:labels){ Button n=btn(x); n.setTextColor(NAVY); n.setBackground(round(Color.WHITE,8));
            n.setOnClickListener(v->{ if(x.equals("Accueil"))showDashboard(); else if(x.equals("Clients"))showClients(); else if(x.equals("Services"))showServices(); else showInvoice();});
            nav.addView(n,new LinearLayout.LayoutParams(0,dp(54),1)); }
        root.addView(nav); setContentView(root);
    }

    TextView stat(String label,String value) {
        TextView s=tv(label+"\\n"+value,15,NAVY); s.setGravity(Gravity.CENTER); s.setBackground(round(Color.WHITE,14));
        s.setPadding(dp(10),dp(14),dp(10),dp(14)); return s;
    }

    void showDashboard() {
        base("NABIYOULAHI TRAVEL");
        ImageView logo=new ImageView(this); int id=getResources().getIdentifier("nabiyoulahi_logo","drawable",getPackageName());
        logo.setImageResource(id); logo.setAdjustViewBounds(true); content.addView(logo,new LinearLayout.LayoutParams(-1,dp(145)));
        TextView welcome=tv("Tableau de bord",24,NAVY); welcome.setTypeface(null,1); content.addView(welcome);
        LinearLayout grid=new LinearLayout(this); grid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout r1=new LinearLayout(this); r1.addView(stat("Clients",String.valueOf(db.count("clients"))),new LinearLayout.LayoutParams(0,dp(88),1));
        r1.addView(stat("Services",String.valueOf(db.count("services"))),new LinearLayout.LayoutParams(0,dp(88),1));
        grid.addView(r1);
        LinearLayout r2=new LinearLayout(this); r2.setPadding(0,dp(8),0,0);
        r2.addView(stat("Total facturé",String.format("%.0f FCFA",db.sum("amount"))),new LinearLayout.LayoutParams(0,dp(88),1));
        r2.addView(stat("Encaissé",String.format("%.0f FCFA",db.sum("paid"))),new LinearLayout.LayoutParams(0,dp(88),1));
        grid.addView(r2); content.addView(grid);
        TextView sub=tv("Services rapides",19,NAVY); sub.setTypeface(null,1); content.addView(sub);
        String[] quick={"✈️ Vente de billet","🛂 Nouveau visa","🕋 Omra / Hajj","🏨 Réservation hôtel","🧾 Créer une facture"};
        for(String q:quick){ Button b=btn(q); b.setTextColor(NAVY); b.setBackground(round(Color.WHITE,12)); content.addView(b,new LinearLayout.LayoutParams(-1,dp(52))); b.setOnClickListener(v->{if(q.contains("facture"))showInvoice();else showServices();});}
    }

    void showClients() {
        base("Clients");
        Button add=btn("+ Ajouter un client"); content.addView(add,new LinearLayout.LayoutParams(-1,dp(52)));
        add.setOnClickListener(v->addClientDialog());
        TextView info=tv("Les clients sont enregistrés localement sur le téléphone.",13,Color.DKGRAY); content.addView(info);
        android.database.Cursor c=db.getReadableDatabase().rawQuery("SELECT name,phone,email FROM clients ORDER BY id DESC",null);
        while(c.moveToNext()){ TextView row=tv("👤 "+c.getString(0)+"\\n"+c.getString(1)+"  •  "+c.getString(2),15,NAVY); row.setBackground(round(Color.WHITE,12)); content.addView(row,new LinearLayout.LayoutParams(-1,dp(78))); }
        c.close();
    }

    void addClientDialog(){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(20),0,dp(20),0);
        EditText n=new EditText(this); n.setHint("Nom complet"); EditText p=new EditText(this); p.setHint("Téléphone"); EditText e=new EditText(this); e.setHint("Email");
        box.addView(n);box.addView(p);box.addView(e);
        new AlertDialog.Builder(this).setTitle("Nouveau client").setView(box).setPositiveButton("Enregistrer",(d,w)->{db.addClient(n.getText().toString(),p.getText().toString(),e.getText().toString());showClients();}).setNegativeButton("Annuler",null).show();
    }

    void showServices() {
        base("Billets • Visas • Omra • Hajj • Hôtels");
        String[] types={"✈️ Billet d'avion","🛂 Visa","🕋 Omra","🕋 Hajj","🏨 Hôtel","🌍 Pack voyage"};
        for(String type:types){ Button b=btn(type); b.setTextColor(NAVY); b.setBackground(round(Color.WHITE,12)); content.addView(b,new LinearLayout.LayoutParams(-1,dp(58))); b.setOnClickListener(v->serviceDialog(type));}
        TextView h=tv("Historique récent",19,NAVY); h.setTypeface(null,1); content.addView(h);
        android.database.Cursor c=db.getReadableDatabase().rawQuery("SELECT client,type,destination,amount,paid,date FROM services ORDER BY id DESC LIMIT 20",null);
        while(c.moveToNext()){ TextView row=tv(c.getString(1)+" • "+c.getString(0)+"\\n"+c.getString(2)+" • "+c.getDouble(3)+" FCFA • payé "+c.getDouble(4)+"\\n"+c.getString(5),14,NAVY); row.setBackground(round(Color.WHITE,12)); content.addView(row,new LinearLayout.LayoutParams(-1,dp(86))); }
        c.close();
    }

    void serviceDialog(String type){
        LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(20),0,dp(20),0);
        EditText client=new EditText(this); client.setHint("Client"); EditText dest=new EditText(this); dest.setHint("Destination / détails");
        EditText amount=new EditText(this); amount.setHint("Montant total (FCFA)"); amount.setInputType(2);
        EditText paid=new EditText(this); paid.setHint("Montant payé (FCFA)"); paid.setInputType(2);
        box.addView(client);box.addView(dest);box.addView(amount);box.addView(paid);
        new AlertDialog.Builder(this).setTitle(type).setView(box).setPositiveButton("Enregistrer",(d,w)->{
            double a=parse(amount.getText().toString()), p=parse(paid.getText().toString());
            db.addService(client.getText().toString(),type,dest.getText().toString(),a,p,new SimpleDateFormat("dd/MM/yyyy",Locale.FRANCE).format(new Date())); showServices();
        }).setNegativeButton("Annuler",null).show();
    }
    double parse(String s){try{return Double.parseDouble(s.replace(" ","").replace(",","."));}catch(Exception e){return 0;}}

    void showInvoice(){
        base("Créer une facture");
        EditText client=new EditText(this); client.setHint("Nom du client"); content.addView(client);
        EditText service=new EditText(this); service.setHint("Service (billet, visa, Omra...)"); content.addView(service);
        EditText dest=new EditText(this); dest.setHint("Destination / description"); content.addView(dest);
        EditText total=new EditText(this); total.setHint("Total FCFA"); total.setInputType(2); content.addView(total);
        EditText paid=new EditText(this); paid.setHint("Déjà payé FCFA"); paid.setInputType(2); content.addView(paid);
        Button create=btn("🧾 Générer le PDF"); content.addView(create,new LinearLayout.LayoutParams(-1,dp(54)));
        create.setOnClickListener(v->{
            try{
                Uri uri=InvoicePdf.create(this,client.getText().toString(),service.getText().toString(),dest.getText().toString(),parse(total.getText().toString()),parse(paid.getText().toString()));
                Intent send=new Intent(Intent.ACTION_SEND); send.setType("application/pdf"); send.putExtra(Intent.EXTRA_STREAM,uri); send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(send,"Partager la facture"));
            }catch(Exception ex){new AlertDialog.Builder(this).setTitle("Erreur").setMessage(ex.getMessage()).setPositiveButton("OK",null).show();}
        });
        TextView note=tv("Le PDF utilise automatiquement l'identité Nabiyoulahi Travel.",13,Color.DKGRAY); content.addView(note);
    }
}
