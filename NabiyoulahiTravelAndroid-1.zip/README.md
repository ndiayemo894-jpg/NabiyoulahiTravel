# NABIYOULAHI TRAVEL — Android

Starter Android application for managing a travel agency.

## Included
- Dashboard
- Clients
- Air tickets
- Visa dossiers
- Omra & Hajj
- Hotels / packages
- Payment installments
- Invoice generation to PDF
- Share invoice via Android share sheet (WhatsApp can appear if installed)
- Local SQLite database
- Nabiyoulahi Travel logo and navy/gold branding

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Run on an Android phone/emulator.
4. For APK: Build > Build APK(s).

The first version is intentionally local/offline. A later version can add cloud sync, employee accounts, customer portal, online payments, and automated reminders.
