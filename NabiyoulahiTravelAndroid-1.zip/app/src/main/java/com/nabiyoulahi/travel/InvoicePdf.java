package com.nabiyoulahi.travel;

import android.content.Context;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import java.io.*;

public class InvoicePdf {
    public static Uri create(Context context, String client, String service, String destination,
                             double total, double paid) throws Exception {
        PdfDocument doc = new PdfDocument();
        PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
        PdfDocument.Page page = doc.startPage(info);
        Canvas c = page.getCanvas();

        Paint navy = new Paint(); navy.setColor(Color.rgb(16,43,85));
        Paint gold = new Paint(); gold.setColor(Color.rgb(201,149,36));
        Paint text = new Paint(); text.setColor(Color.rgb(23,32,51)); text.setTextSize(14);
        Paint small = new Paint(); small.setColor(Color.DKGRAY); small.setTextSize(11);

        c.drawRect(0,0,595,12,navy);
        c.drawRect(430,0,595,12,gold);

        text.setFakeBoldText(true); text.setTextSize(24);
        c.drawText("NABIYOULAHI TRAVEL", 42, 70, navy);
        text.setTextSize(11); text.setFakeBoldText(false);
        c.drawText("VOYAGEZ. DÉCOUVREZ. VIVEZ.", 43, 90, gold);

        text.setFakeBoldText(true); text.setTextSize(22);
        c.drawText("FACTURE", 410, 70, gold);
        text.setFakeBoldText(false); text.setTextSize(11);
        c.drawText("NT-" + System.currentTimeMillis(), 410, 90, small);

        c.drawLine(42,115,553,115,small);
        text.setTextSize(13); text.setFakeBoldText(true);
        c.drawText("CLIENT", 42, 150, navy);
        text.setFakeBoldText(false); text.setTextSize(14);
        c.drawText(client, 42, 173, text);
        text.setTextSize(13); text.setFakeBoldText(true);
        c.drawText("SERVICE", 320, 150, navy);
        text.setFakeBoldText(false); text.setTextSize(14);
        c.drawText(service, 320, 173, text);
        c.drawText(destination, 320, 195, text);

        c.drawLine(42,225,553,225,small);
        text.setFakeBoldText(true); text.setTextSize(14);
        c.drawText("DÉSIGNATION", 42, 255, navy);
        c.drawText("MONTANT", 440, 255, navy);
        text.setFakeBoldText(false);
        c.drawText(service, 42, 292, text);
        c.drawText(String.format("%.0f FCFA", total), 440, 292, text);

        c.drawLine(42,320,553,320,small);
        text.setFakeBoldText(true); text.setTextSize(18);
        c.drawText("TOTAL", 42, 355, navy);
        c.drawText(String.format("%.0f FCFA", total), 410, 355, text);
        text.setFakeBoldText(false); text.setTextSize(13);
        c.drawText(String.format("Déjà payé : %.0f FCFA", paid), 42, 390, text);
        c.drawText(String.format("Reste à payer : %.0f FCFA", Math.max(0,total-paid)), 42, 415, text);
        text.setColor(Color.DKGRAY); text.setTextSize(11);
        c.drawText("Document généré par Nabiyoulahi Travel", 42, 790, text);

        doc.finishPage(page);
        File dir = new File(context.getCacheDir(), "invoices");
        if (!dir.exists()) dir.mkdirs();
        File file = new File(dir, "facture_" + System.currentTimeMillis() + ".pdf");
        FileOutputStream out = new FileOutputStream(file);
        doc.writeTo(out); out.close(); doc.close();
        return androidx.core.content.FileProvider.getUriForFile(context,
                context.getPackageName()+".provider", file);
    }
}
